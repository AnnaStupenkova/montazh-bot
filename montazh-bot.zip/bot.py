"""Telegram-бот «Монтаж» — монтирует рилсы по правилам Анны.
Запуск: python3 bot.py  (переменные окружения в /opt/montazh/.env)"""
import os, json, asyncio, shutil, time, logging, traceback, re
from pathlib import Path
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from aiogram.filters import Command, CommandStart
from aiogram.types import (Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton as B,
                           ReplyKeyboardMarkup, KeyboardButton, FSInputFile, InputMediaPhoto)

from engine import asr, montage, text, broll, llm, style as S

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("montazh")

TOKEN = os.environ["BOT_TOKEN"]
API_URL = os.environ.get("BOT_API_URL")            # локальный Bot API (файлы до 2 ГБ)
DATA = Path(os.environ.get("DATA", "/opt/montazh/data"))
ADMIN_CODE = os.environ.get("ADMIN_CODE", "").strip()
ALLOWED = {int(x) for x in os.environ.get("ALLOWED_USERS", "").replace(" ", "").split(",") if x}
MUSIC = Path(os.environ.get("MUSIC", str(DATA / "music")))
for p in (DATA / "users", MUSIC): p.mkdir(parents=True, exist_ok=True)
OWNER_FILE = DATA / "owner.json"
OWNER = json.loads(OWNER_FILE.read_text())["id"] if OWNER_FILE.exists() else int(os.environ.get("OWNER_ID", "0"))

session = AiohttpSession(api=TelegramAPIServer.from_base(API_URL, is_local=True)) if API_URL else None
bot = Bot(TOKEN, session=session, default=DefaultBotProperties(parse_mode="HTML")) if session else \
      Bot(TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
dp = Dispatcher()
RENDER = asyncio.Semaphore(1)        # по одному рилсу за раз — дневник на том же сервере не тормозит

DEFAULTS = {"style": "linen", "font": None, "color": None, "subs": "lines", "music": "auto",
            "music_vol": 0.20, "inserts": True, "retouch_cover": True, "badge": True}
MAIN_KB = ReplyKeyboardMarkup(resize_keyboard=True, keyboard=[
    [KeyboardButton(text="🎬 Новый рилс")],
    [KeyboardButton(text="⚙️ Настройки"), KeyboardButton(text="🎞 Мои видео"), KeyboardButton(text="🎵 Музыка")]])


# ---------- хранение ----------
def udir(uid):
    d = DATA / "users" / str(uid); d.mkdir(parents=True, exist_ok=True); return d


def settings(uid):
    p = udir(uid) / "settings.json"
    s = dict(DEFAULTS)
    if p.exists(): s.update(json.loads(p.read_text()))
    return s


def save_settings(uid, s):
    (udir(uid) / "settings.json").write_text(json.dumps(s, ensure_ascii=False))


def job(uid):
    p = udir(uid) / "job.json"
    return json.loads(p.read_text()) if p.exists() else None


def save_job(uid, j):
    (udir(uid) / "job.json").write_text(json.dumps(j, ensure_ascii=False))


def allowed(uid):
    return (OWNER and uid == OWNER) or uid in ALLOWED or uid in extra_users()


def extra_users():
    p = DATA / "users.json"
    return set(json.loads(p.read_text())) if p.exists() else set()


async def deny(m: Message):
    await m.answer("Бот пока работает в закрытом режиме.")


# ---------- настройка с сервера через бота (только владелец) ----------
ENV_FILE = os.environ.get("ENV_FILE", "/opt/montazh/.env")


def set_env(key, val):
    lines = Path(ENV_FILE).read_text().splitlines() if os.path.exists(ENV_FILE) else []
    lines = [l for l in lines if not l.startswith(key + "=")] + [f"{key}={val}"]
    Path(ENV_FILE).write_text("\n".join(lines) + "\n"); os.chmod(ENV_FILE, 0o600)


async def restart_self():
    await asyncio.sleep(2)
    os.system("systemctl restart montazh &")


@dp.message(Command("bigfiles"))
async def bigfiles(m: Message):
    """/bigfiles api_id api_hash — включить приём файлов больше 20 МБ."""
    if m.from_user.id != OWNER: return
    try: await m.delete()          # ключи не держим в переписке
    except Exception: pass
    parts = m.text.split()
    if len(parts) != 3 or not parts[1].isdigit():
        return await m.answer("Формат: /bigfiles api_id api_hash")
    if not os.path.exists("/usr/local/bin/telegram-bot-api"):
        return await m.answer("Сервер больших файлов ещё собирается после установки. Попробуйте через 30–60 минут.")
    Path("/root/tgapi.env").write_text(f"TG_API_ID={parts[1]}\nTG_API_HASH={parts[2]}\n"); os.chmod("/root/tgapi.env", 0o600)
    os.system("systemctl enable --now tgapi")
    import urllib.request, urllib.error
    ok = False
    for _ in range(20):
        await asyncio.sleep(1)
        try: urllib.request.urlopen("http://127.0.0.1:8081/", timeout=2)
        except urllib.error.HTTPError: ok = True; break
        except Exception: pass
    if not ok:
        return await m.answer("Локальный сервер Telegram не запустился. Проверьте api_id и api_hash.")
    await m.answer("✅ Ключи приняты. Переключаюсь на большие файлы, бот перезапустится за минуту…")
    try: await bot.log_out()
    except Exception as e: log.warning("logout: %s", e)
    set_env("BOT_API_URL", "http://127.0.0.1:8081")
    asyncio.create_task(restart_self())


@dp.message(Command("gigachat"))
async def gigachat(m: Message):
    """/gigachat КЛЮЧ — подключить ИИ-помощника (описания, хуки, знаки препинания)."""
    if m.from_user.id != OWNER: return
    try: await m.delete()
    except Exception: pass
    parts = m.text.split(maxsplit=1)
    if len(parts) != 2: return await m.answer("Формат: /gigachat ключ_авторизации")
    set_env("GIGACHAT_KEY", parts[1].strip())
    await m.answer("✅ Ключ GigaChat сохранён. Перезапускаюсь…")
    asyncio.create_task(restart_self())


@dp.message(Command("status"))
async def status(m: Message):
    if m.from_user.id != OWNER: return
    await m.answer(f"Большие файлы: {'да' if API_URL else 'нет (до 20 МБ)'}\n"
                   f"ИИ-помощник: {'да' if llm.available() else 'нет'}\n"
                   f"Pixabay: {'да' if broll.PIXABAY_KEY else 'нет'}")


# ---------- старт ----------
@dp.message(F.text.func(lambda t: bool(ADMIN_CODE) and t.strip() == ADMIN_CODE))
async def claim(m: Message):
    global OWNER
    if not OWNER:
        OWNER = m.from_user.id; OWNER_FILE.write_text(json.dumps({"id": OWNER}))
        return await m.answer("Вы владелец бота ✅", reply_markup=MAIN_KB)
    await m.answer("Владелец уже назначен.")


@dp.message(Command("adduser"))
async def add_user(m: Message):
    if m.from_user.id != OWNER: return
    try: uid = int(m.text.split()[1])
    except Exception: return await m.answer("Формат: /adduser 123456789 (id человека из его команды /id)")
    us = extra_users() | {uid}; (DATA / "users.json").write_text(json.dumps(sorted(us)))
    await m.answer(f"Доступ выдан: {uid} ✅")


@dp.message(CommandStart())
async def start(m: Message):
    if not OWNER: return await m.answer("Отправьте кодовое слово, чтобы стать владельцем бота.")
    if not allowed(m.from_user.id): return await deny(m)
    await m.answer("Привет! Я монтирую рилсы.\n\n"
                   "Нажмите <b>🎬 Новый рилс</b> и пришлите видео <b>файлом</b> "
                   "(скрепка → Файл), так оно не сожмётся.", reply_markup=MAIN_KB)


@dp.message(Command("id"))
async def my_id(m: Message):
    await m.answer(f"Ваш id: <code>{m.from_user.id}</code>")


@dp.message(F.text == "🎬 Новый рилс")
async def new_reel(m: Message):
    if not allowed(m.from_user.id): return await deny(m)
    save_job(m.from_user.id, {"stage": "wait_video"})
    await m.answer("Пришлите видео <b>файлом</b> (скрепка → Файл). Длина до 7 минут.")


# ---------- настройки ----------
def settings_kb(s):
    st = S.STYLES[s["style"]]["name"]
    fn = S.FONT_NAMES.get(s["font"] or S.STYLES[s["style"]]["font"])
    col = S.COLOR_NAMES.get(s["color"] or S.STYLES[s["style"]]["color"])
    mus = {"auto": "из библиотеки", "off": "без музыки"}.get(s["music"], s["music"])
    return InlineKeyboardMarkup(inline_keyboard=[
        [B(text=f"Стиль: {st}", callback_data="set:style")],
        [B(text=f"Шрифт: {fn}", callback_data="set:font"), B(text=f"Плашка: {col}", callback_data="set:color")],
        [B(text=f"Субтитры: {'фразами' if s['subs']=='lines' else 'по словам'}", callback_data="tg:subs")],
        [B(text=f"Музыка: {mus}", callback_data="set:music")],
        [B(text=f"Вставки: {'вкл' if s['inserts'] else 'выкл'}", callback_data="tg:inserts"),
         B(text=f"Ретушь обложки: {'вкл' if s['retouch_cover'] else 'выкл'}", callback_data="tg:retouch_cover")],
        [B(text=f"«Включи звук»: {'да' if s['badge'] else 'нет'}", callback_data="tg:badge")],
        [B(text="👁 Показать пример", callback_data="preview")]])


@dp.message(F.text == "⚙️ Настройки")
async def show_settings(m: Message):
    if not allowed(m.from_user.id): return await deny(m)
    await m.answer("Настройки монтажа:", reply_markup=settings_kb(settings(m.from_user.id)))


@dp.callback_query(F.data.startswith("tg:"))
async def toggle(c: CallbackQuery):
    s = settings(c.from_user.id); k = c.data[3:]
    s[k] = ("words" if s[k] == "lines" else "lines") if k == "subs" else (not s[k])
    save_settings(c.from_user.id, s)
    await c.message.edit_reply_markup(reply_markup=settings_kb(s)); await c.answer()


@dp.callback_query(F.data.startswith("set:"))
async def choose(c: CallbackQuery):
    k = c.data[4:]
    if k == "style": opts = [(v["name"], key) for key, v in S.STYLES.items()]
    elif k == "font": opts = [(v, key) for key, v in S.FONT_NAMES.items()] + [("Как в стиле", "-")]
    elif k == "color": opts = [(v, key) for key, v in S.COLOR_NAMES.items()] + [("Как в стиле", "-")]
    else:
        moods = sorted(p.name for p in MUSIC.iterdir() if p.is_dir())
        opts = [("Любая из библиотеки", "auto")] + [(x, x) for x in moods] + [("Без музыки", "off")]
    rows = [[B(text=t, callback_data=f"val:{k}:{v}")] for t, v in opts]
    await c.message.edit_reply_markup(reply_markup=InlineKeyboardMarkup(inline_keyboard=rows)); await c.answer()


@dp.callback_query(F.data.startswith("val:"))
async def set_val(c: CallbackQuery):
    _, k, v = c.data.split(":", 2); s = settings(c.from_user.id)
    s[k] = None if v == "-" else v
    if k == "style": s["font"] = None; s["color"] = None
    save_settings(c.from_user.id, s)
    await c.message.edit_reply_markup(reply_markup=settings_kb(s)); await c.answer("Сохранено")


@dp.callback_query(F.data == "preview")
async def preview(c: CallbackQuery):
    s = settings(c.from_user.id); d = udir(c.from_user.id)
    from PIL import Image
    bg = Image.new("RGBA", (1080, 1920), (205, 196, 182, 255))
    j = job(c.from_user.id) or {}
    if j.get("src") and os.path.exists(j["src"]):
        fr = str(d / "pv.jpg")
        montage.run(["ffmpeg", "-v", "error", "-y", "-ss", "2", "-i", j["src"], "-frames:v", "1",
                     "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920", fr])
        bg = Image.open(fr).convert("RGBA")
    bg.alpha_composite(S.title_plate("Заголовок рилса", "вторая строка", s["style"], s["color"]), (0, 110))
    bg.alpha_composite(S.plate(["Так будут выглядеть", "ваши субтитры"], s["style"], s["font"], s["color"]), (0, 1330))
    p = d / "preview.jpg"; bg.convert("RGB").resize((540, 960)).save(p, quality=88)
    await c.message.answer_photo(FSInputFile(p)); await c.answer()


# ---------- музыка и свои видео ----------
@dp.message(F.text == "🎵 Музыка")
async def music_help(m: Message):
    moods = {p.name: len(list(p.glob("*.mp3"))) for p in MUSIC.iterdir() if p.is_dir()}
    lst = "\n".join(f"• {k}: {v}" for k, v in moods.items()) or "пока пусто"
    save_job(m.from_user.id, {**(job(m.from_user.id) or {}), "stage": "wait_music"})
    await m.answer(f"Библиотека музыки:\n{lst}\n\nПришлите mp3 <b>файлом</b>, в подписи — настроение "
                   "(например: <i>спокойная</i>, <i>светлая</i>, <i>вдохновляющая</i>).")


@dp.message(F.text == "🎞 Мои видео")
async def lib_help(m: Message):
    n = len(broll.library_index(str(udir(m.from_user.id) / "library")))
    save_job(m.from_user.id, {**(job(m.from_user.id) or {}), "stage": "wait_lib"})
    await m.answer(f"Ваших клипов в библиотеке: {n}.\n\nПришлите короткий клип (3–10 сек) <b>файлом</b>, "
                   "в подписи — слова, к чему он подходит: <i>утро, кровать, окно, просыпание</i>. "
                   "Бот будет ставить ваши клипы в первую очередь.")


async def fetch_file(file_id, dest):
    f = await bot.get_file(file_id)
    if API_URL and os.path.isabs(f.file_path) and os.path.exists(f.file_path):
        shutil.copy(f.file_path, dest)        # локальный сервер отдаёт путь на диске
    else:
        await bot.download_file(f.file_path, dest)
    return dest


@dp.message(F.document | F.video | F.audio)
async def got_file(m: Message):
    uid = m.from_user.id
    if not allowed(uid): return await deny(m)
    j = job(uid) or {"stage": "wait_video"}
    obj = m.document or m.video or m.audio
    name = (getattr(obj, "file_name", None) or "file").lower()
    if j.get("stage") == "wait_music" or name.endswith(".mp3") or m.audio:
        mood = (m.caption or "спокойная").strip().lower()[:30]
        d = MUSIC / mood; d.mkdir(exist_ok=True)
        await fetch_file(obj.file_id, str(d / re.sub(r"[^\w.\-]", "_", name)))
        return await m.answer(f"Трек добавлен в «{mood}» ✅")
    if j.get("stage") == "wait_lib":
        lib = udir(uid) / "library"; lib.mkdir(exist_ok=True)
        p = str(lib / f"{int(time.time())}_{re.sub(r'[^\w.\-]', '_', name)}")
        await fetch_file(obj.file_id, p)
        tags = [t.strip() for t in re.split(r"[,\s]+", m.caption or "") if t.strip()]
        broll.library_add(str(lib), p, tags)
        return await m.answer(f"Клип сохранён с метками: {', '.join(tags) or 'без меток'} ✅")
    # видео для рилса
    if m.video and not m.document:
        await m.answer("Получила. Совет: в следующий раз шлите <b>файлом</b>, так качество лучше.")
    wd = udir(uid) / f"r{int(time.time())}"; wd.mkdir()
    msg = await m.answer("⏳ Загружаю видео…")
    src = str(wd / "src.mp4")
    try:
        await fetch_file(obj.file_id, src)
    except Exception as e:
        if "too big" in str(e).lower():
            return await msg.edit_text("Файл больше 20 МБ. Пока большие файлы не включены (команда /bigfiles), "
                                       "пришлите это видео <b>как видео</b>, не файлом — Telegram его сожмёт.")
        return await msg.edit_text(f"Не получилось скачать файл.\n<code>{e}</code>")
    dur = montage.probe(src)
    if dur > 7 * 60 + 5:
        return await msg.edit_text("Видео длиннее 7 минут. Пришлите покороче.")
    j = {"stage": "wait_hook", "wd": str(wd), "src": src, "dur": dur}
    save_job(uid, j)
    await msg.edit_text("✅ Видео получено.\n\nНапишите <b>заголовок</b>: первая строка — главная, вторая — подзаголовок "
                        "(можно одну строку). Или нажмите «Предложи».",
                        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[B(text="✨ Предложи", callback_data="hook:auto")]]))
    asyncio.create_task(recognize(uid, m.chat.id))


# ---------- распознавание ----------
async def recognize(uid, chat):
    j = job(uid); wd = Path(j["wd"])
    try:
        wav = str(wd / "a.wav")
        await asyncio.to_thread(montage.extract_wav, j["src"], wav)
        words, phrases = await asyncio.to_thread(asr.transcribe, wav, 2)
        raw = text.as_text(words)
        fixed = None
        if llm.available():
            try: fixed = await asyncio.to_thread(llm.punctuate, raw)
            except Exception as e: log.warning("llm punct: %s", e)
        if fixed:
            words = text.apply(words, fixed)
        else:
            words = text.prettify(words)
        j = job(uid); j.update({"words": words, "text": text.as_text(words), "asr_done": True}); save_job(uid, j)
        if j.get("stage") == "wait_asr": await after_hook(uid, chat)
    except Exception as e:
        log.error(traceback.format_exc())
        await bot.send_message(chat, f"Ошибка распознавания: <code>{e}</code>")


@dp.callback_query(F.data == "hook:auto")
async def hook_auto(c: CallbackQuery):
    j = job(c.from_user.id); j["hook"] = None; j["stage"] = "wait_asr"; save_job(c.from_user.id, j)
    await c.message.edit_reply_markup(); await c.answer()
    if j.get("asr_done"): await after_hook(c.from_user.id, c.message.chat.id)
    else: await c.message.answer("⏳ Распознаю речь…")


@dp.message(F.text & ~F.text.startswith("/"))
async def on_text(m: Message):
    uid = m.from_user.id
    if not allowed(uid): return await deny(m)
    j = job(uid) or {}
    st = j.get("stage")
    if st == "wait_hook":
        lines = [l.strip() for l in m.text.strip().split("\n") if l.strip()]
        j["hook"] = [lines[0], " ".join(lines[1:])] if lines else None
        if j.get("rendered"):           # смена хука после готового рилса — сразу пересобрать
            save_job(uid, j); return await do_render(uid, m.chat.id)
        j["stage"] = "wait_asr"; save_job(uid, j)
        if j.get("asr_done"): return await after_hook(uid, m.chat.id)
        return await m.answer("⏳ Распознаю речь…")
    if st == "check_text":
        j["words"] = text.apply(j["words"], m.text); j["text"] = text.as_text(j["words"]); save_job(uid, j)
        await m.answer("Текст исправлен ✅")
        if j.get("rendered"): return await do_render(uid, m.chat.id)
        return await plan_inserts(uid, m.chat.id)
    if st == "rewrite":
        kind = j.pop("rewrite_kind"); j["stage"] = "done"; save_job(uid, j)
        if not llm.available(): return await m.answer("ИИ-помощник не подключён.")
        new = await asyncio.to_thread(llm.rewrite, kind, j["texts"].get(kind, ""), m.text, j["text"])
        j["texts"][kind] = new; save_job(uid, j)
        return await m.answer(new, parse_mode=None)
    await m.answer("Нажмите «🎬 Новый рилс», чтобы начать.", reply_markup=MAIN_KB)


async def after_hook(uid, chat):
    j = job(uid); j["stage"] = "check_text"; save_job(uid, j)
    t = j["text"]
    parts = [t[i:i + 3500] for i in range(0, len(t), 3500)]
    await bot.send_message(chat, "📝 <b>Текст субтитров.</b> Проверьте. Если есть ошибка — скопируйте, исправьте и "
                                 "пришлите целиком. Слова не сокращаю.")
    for p in parts: await bot.send_message(chat, p, parse_mode=None)
    await bot.send_message(chat, "Всё верно?", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [B(text="✅ Да, дальше", callback_data="text:ok")]]))


@dp.callback_query(F.data == "text:ok")
async def text_ok(c: CallbackQuery):
    await c.message.edit_reply_markup(); await c.answer()
    await plan_inserts(c.from_user.id, c.message.chat.id)


# ---------- план: вставки, хуки, тексты ----------
def phrases_of(words):
    gs = montage.group_words(words, maxw=14, maxchars=90)
    return [{"s": g[0]["s"], "e": g[-1]["e"], "t": " ".join(w["w"] for w in g)} for g in gs]


async def plan_inserts(uid, chat):
    j = job(uid); s = settings(uid); wd = Path(j["wd"])
    j["stage"] = "planning"; save_job(uid, j)
    ph = phrases_of(j["words"])
    p = None
    if llm.available():
        await bot.send_message(chat, "⏳ Подбираю вставки и пишу описания…")
        try: p = await asyncio.to_thread(llm.plan, ph)
        except Exception as e: log.warning("plan: %s", e)
    p = p or {}
    if not j.get("hook"):
        hk = (p.get("hooks") or [ph[0]["t"][:40] if ph else "Мой рилс"])[0]
        j["hook"] = [hk, ""]
    j["texts"] = {k: p.get(k, "") for k in ("instagram", "telegram", "youtube_title", "youtube_desc", "tiktok")}
    j["hooks"] = p.get("hooks", [])
    j["inserts"] = []; j["ask"] = []
    if s["inserts"]:
        own = broll.library_match(str(udir(uid) / "library"), ph)
        j["inserts"] += [{"at": o["at"], "path": o["path"], "dur": 3.5} for o in own]
        if len(j["inserts"]) < 5:
            taken = {round(x["at"]) for x in j["inserts"]}
            for it in (p.get("inserts") or [])[:5 - len(j["inserts"])]:
                if it.get("at", 0) < 8 or round(it["at"]) in taken: continue
                j["ask"].append(it)
    save_job(uid, j)
    if j["ask"]:
        await bot.send_message(chat, f"🎞 Предлагаю {len(j['ask'])} вставок. Выберите кадр или «Без вставки».")
        return await ask_next(uid, chat)
    await do_render(uid, chat)


async def ask_next(uid, chat):
    j = job(uid)
    while j["ask"]:
        it = j["ask"][0]; wd = Path(j["wd"]) / "cand"
        cs = await asyncio.to_thread(broll.candidates, it["query"], str(wd), 3)
        if not cs:
            j["ask"].pop(0); save_job(uid, j); continue
        it["cands"] = cs; save_job(uid, j)
        media = [InputMediaPhoto(media=FSInputFile(c["thumb_path"]), caption=(f"«{it['phrase'][:120]}»" if i == 0 else None))
                 for i, c in enumerate(cs)]
        await bot.send_media_group(chat, media)
        kb = [[B(text=str(i + 1), callback_data=f"ins:{i}") for i in range(len(cs))], [B(text="✖ Без вставки", callback_data="ins:x")]]
        return await bot.send_message(chat, "Какой кадр?", reply_markup=InlineKeyboardMarkup(inline_keyboard=kb))
    await do_render(uid, chat)


@dp.callback_query(F.data.startswith("ins:"))
async def ins_pick(c: CallbackQuery):
    uid = c.from_user.id; j = job(uid); await c.message.edit_reply_markup(); await c.answer()
    if not j.get("ask"): return
    it = j["ask"].pop(0)
    if c.data != "ins:x":
        cand = it["cands"][int(c.data[4:])]
        path = await asyncio.to_thread(broll.download, cand, str(Path(j["wd"]) / "cand"))
        if path: j["inserts"].append({"at": it["at"], "path": path, "dur": 3.5, "clip_start": 0.5})
    save_job(uid, j)
    await ask_next(uid, c.message.chat.id)


# ---------- сборка ----------
def pick_music(s):
    if s["music"] == "off": return None
    dirs = [MUSIC / s["music"]] if s["music"] != "auto" else [p for p in MUSIC.iterdir() if p.is_dir()]
    tracks = [t for d in dirs if d.exists() for t in d.glob("*.mp3")]
    if not tracks: return None
    import random; return str(random.choice(tracks))


async def do_render(uid, chat):
    j = job(uid); s = settings(uid); wd = Path(j["wd"])
    j["stage"] = "render"; j.setdefault("music", pick_music(s)); save_job(uid, j)
    msg = await bot.send_message(chat, "🎬 Монтирую… обычно 2–3 минуты.")
    out = str(wd / "reel.mp4")
    cfg = {"src": j["src"], "out": out, "wd": str(wd / "w"), "words": j["words"], "style": s["style"],
           "font": s["font"], "color": s["color"], "subs_mode": s["subs"], "t1": j["hook"][0], "t2": j["hook"][1],
           "inserts": j["inserts"], "music": j["music"], "music_vol": s["music_vol"], "sound_badge": s["badge"], "threads": 2}
    t0 = time.time()
    try:
        async with RENDER:
            if os.path.exists(cfg["wd"]): shutil.rmtree(cfg["wd"])
            r = await asyncio.to_thread(montage.build, cfg)
    except Exception as e:
        log.error(traceback.format_exc())
        return await msg.edit_text(f"Ошибка монтажа: <code>{str(e)[-800:]}</code>")
    j["stage"] = "done"; j["out"] = out; j["rendered"] = True; save_job(uid, j)
    await msg.edit_text(f"✅ Готово за {int(time.time() - t0)} сек.")
    await bot.send_document(chat, FSInputFile(out, filename="reel.mp4"), caption="Рилс (файлом — без сжатия)")
    await bot.send_message(chat, "Что дальше?", reply_markup=after_kb())
    await send_covers(uid, chat)


def after_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [B(text="📝 Тексты для соцсетей", callback_data="txt:all")],
        [B(text="🎵 Другая музыка", callback_data="re:music"), B(text="🔇 Без музыки", callback_data="re:nomusic")],
        [B(text="🪝 Другой хук", callback_data="re:hook"), B(text="✏️ Исправить текст", callback_data="re:text")],
        [B(text="🎞 Без вставок", callback_data="re:noins")]])


async def send_covers(uid, chat):
    j = job(uid); wd = Path(j["wd"]); ts = montage.cover_frames(j["src"])
    media = []
    for i, t in enumerate(ts):
        p = str(wd / f"cf{i}.jpg")
        montage.run(["ffmpeg", "-v", "error", "-y", "-ss", str(t), "-i", j["src"], "-frames:v", "1", "-vf", "scale=360:-1", p])
        media.append(InputMediaPhoto(media=FSInputFile(p)))
    j["cover_ts"] = ts; save_job(uid, j)
    await bot.send_media_group(chat, media)
    await bot.send_message(chat, "🖼 Кадр для обложки?", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [B(text=str(i + 1), callback_data=f"cov:{i}") for i in range(len(ts))]]))


@dp.callback_query(F.data.startswith("cov:"))
async def cov_pick(c: CallbackQuery):
    uid = c.from_user.id; j = job(uid); s = settings(uid); await c.answer()
    t = j["cover_ts"][int(c.data[4:])]; out = str(Path(j["wd"]) / "cover.jpg")
    await asyncio.to_thread(montage.cover, j["src"], out, j["hook"][0], j["hook"][1], s["style"], s["color"], t, 230, s["retouch_cover"])
    await bot.send_document(c.message.chat.id, FSInputFile(out, filename="cover.jpg"), caption="Обложка")


@dp.callback_query(F.data == "txt:all")
async def texts(c: CallbackQuery):
    j = job(c.from_user.id); await c.answer(); t = j.get("texts") or {}
    if not any(t.values()):
        return await c.message.answer("Тексты пишет ИИ-помощник, он ещё не подключён (нужен ключ YandexGPT или GigaChat).")
    blocks = [("instagram", "📝 Instagram / ВК"), ("telegram", "✈️ Telegram"), ("youtube_title", "🎬 YouTube — название"),
              ("youtube_desc", "🎬 YouTube — описание"), ("tiktok", "📱 TikTok")]
    for k, title in blocks:
        if t.get(k):
            await c.message.answer(f"<b>{title}</b>")
            await c.message.answer(t[k], parse_mode=None, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [B(text="✏️ Поправить", callback_data=f"rw:{k}")]]))
    if j.get("hooks"):
        await c.message.answer("🪝 Варианты хука:\n" + "\n".join(f"{i+1}. {h}" for i, h in enumerate(j["hooks"])))


@dp.callback_query(F.data.startswith("rw:"))
async def rw(c: CallbackQuery):
    j = job(c.from_user.id); j["stage"] = "rewrite"; j["rewrite_kind"] = c.data[3:]; save_job(c.from_user.id, j)
    await c.answer(); await c.message.answer("Напишите, что изменить: «короче», «убери про…», «добавь призыв в директ».")


@dp.callback_query(F.data.startswith("re:"))
async def redo(c: CallbackQuery):
    uid = c.from_user.id; j = job(uid); s = settings(uid); k = c.data[3:]; await c.answer()
    if k == "music": j["music"] = pick_music(s)
    elif k == "nomusic": j["music"] = None
    elif k == "noins": j["inserts"] = []
    elif k == "hook":
        j["stage"] = "wait_hook"; j["asr_done"] = True; save_job(uid, j)
        hs = "\n".join(f"• {h}" for h in j.get("hooks", []))
        return await c.message.answer("Напишите новый заголовок (1–2 строки)." + (f"\n\nВарианты:\n{hs}" if hs else ""))
    elif k == "text":
        j["stage"] = "check_text"; save_job(uid, j)
        await c.message.answer("Скопируйте текст, исправьте и пришлите целиком:")
        return await c.message.answer(j["text"], parse_mode=None)
    save_job(uid, j); await do_render(uid, c.message.chat.id)


async def main():
    log.info("bot start; local api=%s; llm=%s; pixabay=%s", API_URL, llm.available(), bool(broll.PIXABAY_KEY))
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
