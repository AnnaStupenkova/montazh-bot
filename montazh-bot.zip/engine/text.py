"""Текст субтитров: заглавные буквы, мат со звёздочками, применение правок пользователя."""
import re, difflib

BAD = re.compile(r"\b(х[уy][йеёяи]\w*|п[иi]зд\w*|бл[яa]д?\w*|[её]б\w*|сук[аи]\w*|муд[аи]\w*)\b", re.I)


def mask(w):
    if BAD.fullmatch(w.strip(".,!?…:;»«\"")):
        core = re.sub(r"[^\wё]", "", w, flags=re.I)
        return w.replace(core, core[0] + "*" * (len(core) - 1))
    return w


def norm(w):
    return re.sub(r"[^\wё]", "", w.lower().replace("ё", "е"))


def prettify(words, pause=0.6):
    """Заглавная в начале и после длинной паузы; мат → звёздочки."""
    prev_e = -10
    for w in words:
        w["w"] = mask(w["w"])
        if w["s"] - prev_e > pause and w["w"]:
            w["w"] = w["w"][0].upper() + w["w"][1:]
        prev_e = w["e"]
    return words


def as_text(words, pause=0.6):
    """Текст для проверки пользователем: новая строка на паузе."""
    out, line, prev_e = [], [], None
    for w in words:
        if prev_e is not None and w["s"] - prev_e > pause and line:
            out.append(" ".join(line)); line = []
        line.append(w["w"]); prev_e = w["e"]
    if line: out.append(" ".join(line))
    return "\n".join(out)


def apply(words, corrected):
    """Переносит исправленный текст на тайм-коды распознанных слов."""
    new = []
    for x in corrected.split():
        if not norm(x) and new: new[-1] += " " + x   # «—» и т.п. приклеиваем к предыдущему слову
        else: new.append(x)
    a = [norm(w["w"]) for w in words]; b = [norm(x) for x in new]
    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    out = []
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal" or (op == "replace" and i2 - i1 == j2 - j1):
            for i, j in zip(range(i1, i2), range(j1, j2)):
                out.append({"w": new[j], "s": words[i]["s"], "e": words[i]["e"]})
        elif op in ("replace", "insert"):
            # распределить новые слова по времени заменённого куска
            if i2 > i1:
                s, e = words[i1]["s"], words[i2 - 1]["e"]
            else:
                s = out[-1]["e"] if out else (words[i1]["s"] if i1 < len(words) else 0)
                e = words[i1]["s"] if i1 < len(words) else s + 0.3 * (j2 - j1)
                if e - s < 0.05 * (j2 - j1): e = s + 0.05 * (j2 - j1)
            n = j2 - j1; L = sum(len(x) for x in new[j1:j2]) or 1; t = s
            for j in range(j1, j2):
                d = (e - s) * len(new[j]) / L
                out.append({"w": new[j], "s": round(t, 3), "e": round(t + d, 3)}); t += d
        # delete: слова пропадают
    return out
