"""Монтаж рилса: паузы, субтитры одной дорожкой, заголовок, вставки, музыка, громкость.

Правила (от Анны, 09.11.2026):
- без стикеров; без чужих лиц; вставок 3–5, только по смыслу; светлые кадры;
- плавные переходы ~0,7 с; строки не налезают; «включи звук» не перекрывает субтитры;
- субтитры слово в слово; звук до последней секунды; музыка тихо под голосом.
"""
import os, json, math, subprocess, shutil, random
from PIL import Image
from . import style as S

FPS = 30
W, H = 1080, 1920


def run(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if r.returncode != 0:
        raise RuntimeError(" ".join(cmd[:3]) + "\n" + r.stderr[-1500:])
    return r.stdout


def probe(path):
    out = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path])
    return float(out.strip() or 0)


def extract_wav(src, wav):
    run(["ffmpeg", "-v", "error", "-y", "-i", src, "-ac", "1", "-ar", "16000", wav])


# ---------- паузы ----------
def speech_intervals(words, pre=0.12, post=0.18, join=0.35):
    iv = []
    for w in words:
        a, b = max(0.0, w["s"] - pre), w["e"] + post
        if iv and a - iv[-1][1] < join: iv[-1][1] = max(iv[-1][1], b)
        else: iv.append([a, b])
    return iv


class TimeMap:
    def __init__(self, iv):
        self.iv = []; off = 0.0
        for a, b in iv:
            self.iv.append((a, b, off)); off += b - a
        self.total = off

    def __call__(self, t):
        for a, b, o in self.iv:
            if t <= b: return o + max(0.0, t - a)
        a, b, o = self.iv[-1]; return o + (b - a)


# ---------- субтитры ----------
def _end(w):
    return w["w"].rstrip("»\"')")[-1:]


def group_words(words, maxw=7, maxchars=40, gap_break=0.45):
    """Слова → группы по 2 строки. Разрыв: конец фразы, пауза, запятая (если уже ≥3 слов), длина.
    При превышении длины откатываемся к последней запятой в группе."""
    groups, cur = [], []
    for w in words:
        if cur:
            gap = w["s"] - cur[-1]["e"]
            chars = sum(len(x["w"]) + 1 for x in cur) + len(w["w"])
            e = _end(cur[-1])
            if e in ".!?…" or gap > gap_break or (e in ",:;—" and len(cur) >= 3):
                groups.append(cur); cur = []
            elif len(cur) >= maxw or chars > maxchars:
                cut = max((i for i, x in enumerate(cur[:-1]) if _end(x) in ",:;—" and i >= 1), default=None)
                if cut is not None:
                    groups.append(cur[:cut + 1]); cur = cur[cut + 1:]
                else:
                    # не оставлять в конце строки предлог/союз
                    k = len(cur)
                    while k > 1 and len(cur[k - 1]["w"]) <= 2: k -= 1
                    groups.append(cur[:k]); cur = cur[k:]
        cur.append(w)
    if cur: groups.append(cur)
    # склеить висячие одиночные слова с соседом
    out = []
    for g in groups:
        if out and len(g) == 1 and len(out[-1]) < maxw and g[0]["s"] - out[-1][-1]["e"] < 0.6:
            out[-1] = out[-1] + g
        else:
            out.append(g)
    return out


def split_lines(ws):
    if len(ws) < 3 or len(" ".join(ws)) <= 22: return [" ".join(ws)]
    best = None
    for k in range(1, len(ws)):
        a, b = " ".join(ws[:k]), " ".join(ws[k:])
        sc = abs(len(a) - len(b))
        if best is None or sc < best[0]: best = (sc, [a, b])
    return best[1]


def render_subs(groups, tm, wd, st, font_key, color, mode, total):
    """Рисует PNG и concat-список → одна дорожка субтитров."""
    os.makedirs(wd, exist_ok=True)
    blank = os.path.join(wd, "blank.png")
    hmax = 0; frames = []  # (path, start, end)
    for gi, g in enumerate(groups):
        ws = [w["w"] for w in g]
        lines = split_lines(ws)
        s0, e0 = tm(g[0]["s"]), tm(g[-1]["e"])
        if mode == "words":
            # по словам: подсветка текущего слова
            idx = 0
            for li, l in enumerate(lines):
                for wi, _ in enumerate(l.split(" ")):
                    w = g[idx]; idx += 1
                    p = os.path.join(wd, f"s{gi:03d}_{idx:02d}.png")
                    im = S.plate(lines, st, font_key, color, seed=gi + 20, hi=(li, wi)); im.save(p)
                    hmax = max(hmax, im.height)
                    frames.append((p, tm(w["s"]), tm(w["e"])))
        else:
            p = os.path.join(wd, f"s{gi:03d}.png")
            im = S.plate(lines, st, font_key, color, seed=gi + 20); im.save(p)
            hmax = max(hmax, im.height)
            frames.append((p, s0, e0))
    # непрерывная шкала: держим субтитр до следующего, если пауза короткая
    Image.new("RGBA", (W, hmax), (0, 0, 0, 0)).save(blank)
    lst = []; t = 0.0
    for i, (p, a, b) in enumerate(frames):
        nxt = frames[i + 1][1] if i + 1 < len(frames) else total
        end = nxt if nxt - b < 0.6 else b + 0.15
        if a > t + 0.01: lst.append((blank, a - t))
        a = max(a, t)
        lst.append((p, max(0.04, end - a))); t = a + max(0.04, end - a)
    if total > t: lst.append((blank, total - t))
    txt = os.path.join(wd, "subs.txt")
    with open(txt, "w") as f:
        for p, d in lst:
            # каждое изображение должно иметь одинаковую высоту → подгоняем
            f.write(f"file '{p}'\nduration {d:.3f}\n")
        f.write(f"file '{lst[-1][0]}'\n")
    # выровнять высоту всех кадров (concat требует одинаковый размер)
    for p, _ in lst:
        im = Image.open(p)
        if im.height != hmax:
            c = Image.new("RGBA", (W, hmax), (0, 0, 0, 0)); c.alpha_composite(im, (0, (hmax - im.height) // 2)); c.save(p)
    return txt, hmax


# ---------- сборка ----------
def build(cfg):
    """cfg: src, out, wd, words (из asr), style, font, color, subs_mode (lines|words),
    t1, t2, inserts [{path, at(сек исходника), dur}], music (путь|None), music_vol, sound_badge, retouch"""
    wd = os.path.abspath(cfg["wd"]); os.makedirs(wd, exist_ok=True)
    words = cfg["words"]
    iv = speech_intervals(words)
    tm = TimeMap(iv); total = tm.total
    st = cfg.get("style", "linen"); fk = cfg.get("font"); col = cfg.get("color")

    groups = group_words(words)
    subs_txt, sub_h = render_subs(groups, tm, os.path.join(wd, "subs"), st, fk, col, cfg.get("subs_mode", "lines"), total)
    title = None
    if cfg.get("t1"):
        title = os.path.join(wd, "title.png"); S.title_plate(cfg["t1"], cfg.get("t2", ""), st, col).save(title)
    badge = None
    if cfg.get("sound_badge", True):
        badge = os.path.join(wd, "badge.png"); S.sound_badge().save(badge)

    sel = "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b in iv)
    inp = ["-i", cfg["src"]]
    fc = []
    look = "eq=saturation=1.05:contrast=1.03"
    if cfg.get("retouch"):
        look += ",smartblur=lr=1.2:ls=-0.35:lt=-3.5"
    fc.append(f"[0:v]select='{sel}',setpts=N/FRAME_RATE/TB,fps={FPS},scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,{look}[base]")
    fc.append(f"[0:a]aselect='{sel}',asetpts=N/SR/TB,apad=pad_dur=5,highpass=f=70,loudnorm=I=-14:TP=-1.5:LRA=11[voice]")
    cur = "base"; k = 1
    # вставки
    for j, ins in enumerate([i for i in cfg.get("inserts", []) if tm(i["at"]) >= cfg.get("no_insert_head", 8.0)][:5]):
        a = tm(ins["at"]); d = min(ins.get("dur", 3.5), max(1.5, total - a - 0.3))
        cs = ins.get("clip_start", 0.5)
        inp += ["-ss", str(cs), "-t", f"{d:.2f}", "-i", ins["path"]]
        fc.append(f"[{k}:v]fps={FPS},scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,"
                  f"format=rgba,fade=in:st=0:d=0.7:alpha=1,fade=out:st={d-0.7:.2f}:d=0.7:alpha=1,setpts=PTS-STARTPTS+{a:.3f}/TB[i{j}]")
        fc.append(f"[{cur}][i{j}]overlay=eof_action=pass:enable='between(t,{a:.3f},{a+d:.3f})'[b{j}]"); cur = f"b{j}"; k += 1
    # субтитры одной дорожкой
    inp += ["-f", "concat", "-safe", "0", "-i", subs_txt]
    suby = cfg.get("suby", 1330)
    fc.append(f"[{k}:v]fps={FPS},format=rgba[subs]")
    fc.append(f"[{cur}][subs]overlay=x=0:y={suby}:eof_action=pass[vs]"); cur = "vs"; k += 1
    if title:
        inp += ["-loop", "1", "-t", f"{total:.2f}", "-i", title]
        fc.append(f"[{cur}][{k}:v]overlay=x=0:y=110[vt]"); cur = "vt"; k += 1
    if badge:
        inp += ["-loop", "1", "-t", "3.5", "-i", badge]
        fc.append(f"[{k}:v]format=rgba,fade=out:st=2.9:d=0.5:alpha=1[bd]")
        fc.append(f"[{cur}][bd]overlay=x=0:y={suby + sub_h + 40}:eof_action=pass[vb]"); cur = "vb"; k += 1
    fc.append(f"[{cur}]format=yuv420p[vout]")
    # звук
    if cfg.get("music"):
        inp += ["-stream_loop", "-1", "-i", cfg["music"]]
        vol = cfg.get("music_vol", 0.20)
        fc.append(f"[voice]asplit[vo][vs2]")
        fc.append(f"[{k}:a]volume={vol},atrim=0:{total:.2f},afade=t=in:d=1,afade=t=out:st={total-2:.2f}:d=2[mu]")
        fc.append("[mu][vs2]sidechaincompress=threshold=0.05:ratio=4:attack=30:release=500[md]")
        fc.append(f"[vo][md]amix=inputs=2:duration=first:normalize=0,atrim=0:{total:.2f}[aout]")
    else:
        fc.append(f"[voice]atrim=0:{total:.2f}[aout]")
    threads = str(cfg.get("threads", 0))
    cmd = ["nice", "-n", "15", "ffmpeg", "-v", "error", "-y"] + inp + [
        "-filter_complex", ";".join(fc), "-map", "[vout]", "-map", "[aout]", "-t", f"{total:.2f}",
        "-c:v", "libx264", "-preset", cfg.get("preset", "veryfast"), "-crf", "21", "-maxrate", "6000k", "-bufsize", "12000k",
        "-threads", threads, "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-movflags", "+faststart", cfg["out"]]
    run(cmd)
    return {"duration": total, "groups": [" ".join(w["w"] for w in g) for g in groups], "tm": tm}


def cover_frames(src, n=4):
    """Кандидаты для обложки: кадры из исходника (без надписей), бот предлагает выбрать."""
    d = probe(src); return [round(d * k / (n + 1), 2) for k in range(1, n + 1)]


def cover(src, out, t1, t2, st, color=None, at=1.0, title_y=230, retouch=True):
    """Обложка: кадр из ИСХОДНИКА (без вшитого заголовка) + один заголовок сверху, лицо открыто."""
    fr = out + ".frame.png"
    run(["ffmpeg", "-v", "error", "-y", "-ss", str(at), "-i", src, "-frames:v", "1",
         "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}", fr])
    if retouch:
        from .retouch import retouch_file
        retouch_file(fr, fr + ".jpg"); os.replace(fr + ".jpg", fr)
    im = Image.open(fr).convert("RGBA")
    tp = S.title_plate(t1, t2, st, color); im.alpha_composite(tp, (0, title_y))
    im.convert("RGB").save(out, quality=92); os.remove(fr)
    return out
