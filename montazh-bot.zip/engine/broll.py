"""Вставки: свои видео (по меткам) + Pixabay. Фильтр: без людей, светлые кадры."""
import os, json, time, re, io, urllib.request, urllib.parse
from PIL import Image, ImageStat

PIXABAY_KEY = os.environ.get("PIXABAY_KEY")
UA = {"User-Agent": "Mozilla/5.0 (montazh-bot)"}
PEOPLE = {"woman", "man", "girl", "boy", "people", "person", "face", "portrait", "model", "lady", "child",
          "baby", "couple", "family", "female", "male", "human", "smile", "crowd", "kid", "teen", "guy"}


def _get(url, tries=6):
    for k in range(tries):
        try:
            b = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60).read()
            if len(b) > 1000 or url.endswith(".json") or "api/" in url: return b
        except Exception:
            pass
        time.sleep(5 + 5 * k)
    return None


def pixabay(query, n=12):
    if not PIXABAY_KEY: return []
    u = "https://pixabay.com/api/videos/?" + urllib.parse.urlencode(
        {"key": PIXABAY_KEY, "q": query, "per_page": 30, "safesearch": "true"})
    b = _get(u, 3)
    if not b: return []
    out = []
    for h in json.loads(b).get("hits", []):
        tags = {t.strip() for t in h["tags"].split(",")}
        if tags & PEOPLE or any(t.split()[-1] in PEOPLE for t in tags if t): continue
        v = h["videos"]; m = v.get("medium") or v.get("small")
        if not m or m["width"] < 640: continue
        out.append({"src": "pixabay", "id": h["id"], "tags": h["tags"], "dur": h["duration"],
                    "url": m["url"], "thumb": m.get("thumbnail") or v["small"].get("thumbnail")})
        if len(out) >= n: break
    return out


def bright_enough(img_bytes, minimum=85):
    try:
        im = Image.open(io.BytesIO(img_bytes)).convert("L")
        return ImageStat.Stat(im).mean[0] >= minimum
    except Exception:
        return False


def candidates(query, wd, k=3):
    """Топ-k светлых кадров без людей. Сохраняет превью в wd. Возвращает список кандидатов с полем thumb_path."""
    os.makedirs(wd, exist_ok=True); res = []
    for c in pixabay(query):
        tb = _get(c["thumb"]) if c.get("thumb") else None
        if not tb or not bright_enough(tb): continue
        p = os.path.join(wd, f"px{c['id']}.jpg"); open(p, "wb").write(tb)
        c["thumb_path"] = p; res.append(c)
        if len(res) >= k: break
    return res


def download(c, wd):
    p = os.path.join(wd, f"px{c['id']}.mp4")
    if not os.path.exists(p):
        b = _get(c["url"], 10)
        if not b: return None
        open(p, "wb").write(b)
    return p


# ---------- свои видео ----------
def _stem(w):
    w = re.sub(r"[^\wё]", "", w.lower().replace("ё", "е"))
    return w[:5] if len(w) > 5 else w


def library_index(libdir):
    p = os.path.join(libdir, "index.json")
    return json.load(open(p)) if os.path.exists(p) else []


def library_add(libdir, path, tags):
    idx = library_index(libdir)
    idx.append({"path": path, "tags": tags, "used": 0})
    json.dump(idx, open(os.path.join(libdir, "index.json"), "w"), ensure_ascii=False, indent=1)


def library_match(libdir, phrases, limit=5):
    """Свои клипы по совпадению меток со словами фраз. Возвращает [{at, phrase, path}]."""
    idx = library_index(libdir); out = []; used = set()
    for p in phrases:
        if p["s"] < 8: continue
        ws = {_stem(w) for w in p["t"].split()}
        for c in idx:
            if c["path"] in used: continue
            if any(_stem(t) in ws for t in c["tags"]):
                out.append({"at": p["s"], "phrase": p["t"], "path": c["path"], "src": "own"}); used.add(c["path"]); break
        if len(out) >= limit: break
    return out
