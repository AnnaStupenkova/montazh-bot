"""Стили, шрифты, плашки. Всё рисуется в PNG 1080 по ширине."""
import os, random
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

FONTS_DIR = os.environ.get("FONTS", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fonts")) + "/"
W = 1080

FONTS = {  # ключ: (файл, вариация, коэффициент размера)
    "cormorant": ("corm.ttf", "SemiBold", 1.0),
    "greatvibes": ("GreatVibes-Regular.ttf", None, 1.05),
    "alice": ("Alice-Regular.ttf", None, 0.9),
    "oswald": ("Oswald.ttf", "Medium", 0.92),
    "lora": ("Lora.ttf", "Regular", 0.88),
    "caveat": ("caveat.ttf", "Bold", 1.05),
    "badscript": ("BadScript-Regular.ttf", None, 0.85),
    "kurale": ("Kurale-Regular.ttf", None, 0.88),
}
FONT_NAMES = {"cormorant": "Cormorant", "greatvibes": "Great Vibes", "alice": "Alice", "oswald": "Oswald",
              "lora": "Lora", "caveat": "Caveat", "badscript": "Bad Script", "kurale": "Kurale"}

COLORS = {  # цвет плашки: (заливка RGB, цвет текста)
    "white": ((250, 250, 248), (31, 47, 90)),
    "cream": ((246, 236, 216), (70, 50, 40)),
    "pink": ((248, 226, 232), (120, 50, 75)),
    "lavender": ((232, 226, 246), (60, 50, 110)),
    "mint": ((222, 242, 232), (35, 85, 70)),
    "navy": ((31, 47, 90), (250, 248, 240)),
    "dark": ((22, 22, 28), (255, 255, 255)),
}
COLOR_NAMES = {"white": "Белый", "cream": "Сливочный", "pink": "Пудровый", "lavender": "Лавандовый",
               "mint": "Мятный", "navy": "Синий", "dark": "Тёмный"}

STYLES = {
    # plate: brush|pill|none|dark|marker ; title fonts
    "linen":   {"name": "Бабушкин лён", "plate": "brush",  "font": "cormorant", "color": "white",
                "t1": ("cormorant", "Bold"), "t2": "caveat", "upper1": True},
    "tender":  {"name": "Нежность",     "plate": "pill",   "font": "alice",     "color": "pink",
                "t1": ("greatvibes", None), "t2": "alice", "upper1": False},
    "clean":   {"name": "Чистый",       "plate": "none",   "font": "oswald",    "color": "white",
                "t1": ("oswald", "Regular"), "t2": "oswald", "upper1": True},
    "minimal": {"name": "Минимал",      "plate": "dark",   "font": "lora",      "color": "dark",
                "t1": ("lora", "Regular"), "t2": "lora", "upper1": False},
    "bright":  {"name": "Яркий",        "plate": "marker", "font": "oswald",    "color": "white",
                "t1": ("oswald", "Bold"), "t2": "oswald", "upper1": True},
}

_dd = ImageDraw.Draw(Image.new("RGBA", (10, 10)))


def font(key, size, var=None):
    fn, v, k = FONTS[key]
    f = ImageFont.truetype(FONTS_DIR + fn, int(size * k))
    vv = var or v
    if vv:
        try: f.set_variation_by_name(vv)
        except Exception: pass
    return f


def tsize(t, f):
    b = _dd.textbbox((0, 0), t, font=f)
    return b, b[2] - b[0], b[3] - b[1]


# ---------- мазок кистью ----------
def _smooth(r, n, amp, k=6):
    pts = [r.uniform(-amp, amp) for _ in range(k + 1)]
    out = []
    for i in range(n):
        t = i / (n - 1) * k; j = min(int(t), k - 1); f = t - j; f = f * f * (3 - 2 * f)
        out.append(pts[j] * (1 - f) + pts[j + 1] * f)
    return out


def brush(w, h, rgb=(250, 250, 248), alpha=225, seed=1):
    r = random.Random(seed); pad = 120
    W2, H2 = w + 2 * pad, h + 2 * pad
    out = Image.new("RGBA", (W2, H2), rgb + (0,))
    nb = max(2, min(4, round(h / 90)))
    bh = (h + 30) / (nb - (nb - 1) * 0.22)
    gr = Image.linear_gradient("L").rotate(90, expand=True)
    if gr.getpixel((0, 0)) > gr.getpixel((255, 0)): gr = ImageChops.invert(gr)
    lum = sum(rgb) / 3
    for k in range(nb):
        y0 = pad - 15 + k * bh * 0.78 + r.uniform(-5, 5); y1 = y0 + bh
        x0 = pad - 60 + r.uniform(-15, 15); x1 = pad + w + 60 + r.uniform(-15, 15)
        a = Image.new("L", (W2, H2), 0); d = ImageDraw.Draw(a)
        n = 40; top = _smooth(r, n, 4); bot = _smooth(r, n, 4)
        xs = [x0 + (x1 - x0) * i / (n - 1) for i in range(n)]
        d.polygon([(x, y0 + t) for x, t in zip(xs, top)] + [(x, y1 + b) for x, b in reversed(list(zip(xs, bot)))], fill=255)
        L = int(r.uniform(110, 150))
        fade = Image.new("L", (W2, H2), 255)
        fade.paste(gr.resize((L, H2)), (int(x0), 0)); fade.paste(0, (0, 0, int(x0), H2))
        fade.paste(ImageChops.invert(gr).resize((L, H2)), (int(x1 - L), 0)); fade.paste(0, (int(x1), 0, W2, H2))
        a = ImageChops.multiply(a, fade)
        d2 = ImageDraw.Draw(a); yy = y0 + 3
        while yy < y1 - 3:
            th = r.choice([1, 1, 2, 2, 3])
            if r.random() < 0.7:
                s = x1 - L * r.uniform(0.3, 0.9); e = x1 + r.uniform(-L * 0.2, 45)
                d2.line([(s, yy), (e, yy)], fill=int(255 * r.uniform(.35, .85)), width=th)
            if r.random() < 0.7:
                s = x0 + L * r.uniform(0.3, 0.9); e = x0 - r.uniform(-L * 0.2, 45)
                d2.line([(e, yy), (s, yy)], fill=int(255 * r.uniform(.35, .85)), width=th)
            yy += th + r.choice([0, 1, 1, 2])
        st = Image.new("L", (W2, H2), 255); ds = ImageDraw.Draw(st); yy = 0
        while yy < H2:
            th = r.choice([1, 1, 2, 2, 3, 4]); ds.line([(0, yy), (W2, yy)], fill=int(255 * r.uniform(0.62, 1.0)), width=th); yy += th
        a = ImageChops.multiply(a, st.filter(ImageFilter.GaussianBlur(0.4)))
        a = a.point(lambda v: v * alpha // 255)
        # фактура: лёгкие тёмные/светлые прожилки поверх цвета
        tex = Image.new("L", (W2, H2), 255); dt = ImageDraw.Draw(tex); yy = int(y0)
        while yy < y1:
            if r.random() < 0.18: dt.line([(0, yy), (W2, yy)], fill=int(r.uniform(215, 240)), width=r.choice([1, 2]))
            yy += r.choice([2, 3, 4])
        tex = tex.filter(ImageFilter.GaussianBlur(0.5))
        base = Image.new("RGB", (W2, H2), rgb)
        shade = Image.merge("RGB", [ImageChops.multiply(c, tex) for c in base.split()]) if lum > 100 else base
        out = Image.alpha_composite(out, Image.merge("RGBA", (*shade.split(), a)))
    return out, pad


# ---------- плашка с текстом ----------
def plate(lines, style, font_key=None, color=None, size=74, seed=1, hi=None):
    """lines: список строк; hi: (номер_строки, номер_слова) для подсветки по словам.
    Возвращает RGBA шириной 1080 (текст по центру)."""
    st = STYLES[style]; fk = font_key or st["font"]
    rgb, tc = COLORS[color or st["color"]]
    kind = st["plate"]
    upper = kind in ("marker",) or fk == "oswald"
    if upper: lines = [l.upper() for l in lines]
    while True:
        f = font(fk, size, "Bold" if kind == "marker" else None)
        sz = [tsize(l, f) for l in lines]
        tw = max(s[1] for s in sz)
        if tw <= 900 or size < 44: break
        size -= 4
    lh = max(s[2] for s in sz); asc = f.getmetrics()[0]
    gap = int(lh * 0.45)
    th = lh * len(lines) + gap * (len(lines) - 1)
    padx, pady = 40, 22
    w, h = tw + 2 * padx, th + 2 * pady
    hl_col = (255, 196, 64) if kind != "brush" else (176, 86, 112)

    if kind == "brush":
        pl, pad = brush(w, h, rgb, 215, seed)
    else:
        pad = 30
        pl = Image.new("RGBA", (w + 2 * pad, h + 2 * pad), (0, 0, 0, 0))
        d = ImageDraw.Draw(pl)
        if kind == "pill":
            d.rounded_rectangle((pad, pad, pad + w, pad + h), radius=min(40, h // 2), fill=rgb + (232,))
        elif kind == "dark":
            d.rounded_rectangle((pad, pad, pad + w, pad + h), radius=18, fill=rgb + (160,))
    d = ImageDraw.Draw(pl)
    y = pad + pady
    for i, (l, (b, lw, lhh)) in enumerate(zip(lines, sz)):
        x = pad + (w - lw) // 2
        if kind == "marker":
            mk = Image.new("RGBA", (lw + 30, int(lh * 0.62)), (0, 0, 0, 0))
            ImageDraw.Draw(mk).rounded_rectangle((0, 0, mk.width - 1, mk.height - 1), radius=8, fill=(255, 214, 64, 225))
            pl.alpha_composite(mk.rotate(-1.2, expand=True), (x - 15, y + int(lh * 0.42)))
        if kind in ("none", "marker"):
            sh = Image.new("RGBA", pl.size, (0, 0, 0, 0))
            ImageDraw.Draw(sh).text((x - b[0] + 2, y - b[1] + 3), l, font=f, fill=(0, 0, 0, 170))
            pl.alpha_composite(sh.filter(ImageFilter.GaussianBlur(3)))
            col = (20, 20, 20) if kind == "marker" else (248, 248, 246)
        else:
            col = tc
        if hi and hi[0] == i:
            ws = l.split(" "); xx = x
            for j, wd in enumerate(ws):
                bb, ww, _ = tsize(wd, f)
                c = hl_col if j == hi[1] else col
                d.text((xx - b[0], y - b[1]), wd, font=f, fill=c)
                xx += ww + tsize(" ", f)[1] + (bb[0] - b[0] if j == 0 else 0)
        else:
            d.text((x - b[0], y - b[1]), l, font=f, fill=col)
        y += lh + gap
    out = Image.new("RGBA", (W, pl.height), (0, 0, 0, 0))
    out.alpha_composite(pl, ((W - pl.width) // 2, 0))
    return out


def title_plate(t1, t2, style, color=None, seed=7):
    st = STYLES[style]; rgb, tc = COLORS[color or st["color"]]; kind = st["plate"]
    k1, v1 = st["t1"]; k2 = st["t2"]
    if st["upper1"]: t1 = t1.upper()
    s1, s2 = 76, 70
    while True:
        f1 = font(k1, s1, v1); f2 = font(k2, s2)
        b1, w1, h1 = tsize(t1, f1); b2, w2, h2 = tsize(t2, f2) if t2 else ((0, 0, 0, 0), 0, 0)
        if max(w1, w2) <= 900 or s1 < 40: break
        s1 -= 4; s2 -= 4
    gap = 34 if t2 else 0
    w = max(w1, w2) + 90; h = h1 + h2 + gap + 56
    if kind == "brush":
        pl, pad = brush(w, h, rgb, 205, seed)
    else:
        pad = 30; pl = Image.new("RGBA", (w + 2 * pad, h + 2 * pad), (0, 0, 0, 0)); d = ImageDraw.Draw(pl)
        if kind == "pill": d.rounded_rectangle((pad, pad, pad + w, pad + h), radius=40, fill=rgb + (232,))
        if kind == "dark": d.rounded_rectangle((pad, pad, pad + w, pad + h), radius=18, fill=rgb + (160,))
    d = ImageDraw.Draw(pl)
    col = tc if kind in ("brush", "pill", "dark") else (248, 248, 246)
    y = pad + 28
    for (t, f, (b, ww, hh)) in [(t1, f1, (b1, w1, h1)), (t2, f2, (b2, w2, h2))]:
        if not t: continue
        x = pad + (w - ww) // 2
        if kind == "marker":
            mk = Image.new("RGBA", (ww + 30, int(hh * 0.62)), (0, 0, 0, 0))
            ImageDraw.Draw(mk).rounded_rectangle((0, 0, mk.width - 1, mk.height - 1), radius=8, fill=(255, 214, 64, 225))
            pl.alpha_composite(mk.rotate(-1.2, expand=True), (x - 15, y + int(hh * 0.42)))
        if kind in ("none", "marker"):
            sh = Image.new("RGBA", pl.size, (0, 0, 0, 0))
            ImageDraw.Draw(sh).text((x - b[0] + 2, y - b[1] + 3), t, font=f, fill=(0, 0, 0, 170))
            pl.alpha_composite(sh.filter(ImageFilter.GaussianBlur(3)))
        d.text((x - b[0], y - b[1]), t, font=f, fill=(20, 20, 20) if kind == "marker" else col)
        y += hh + gap
    out = Image.new("RGBA", (W, pl.height), (0, 0, 0, 0))
    out.alpha_composite(pl, ((W - pl.width) // 2, 0))
    return out


def sound_badge():
    f = font("lora", 40)
    t = "включи звук"; b, w, h = tsize(t, f)
    pl = Image.new("RGBA", (w + 130, h + 44), (0, 0, 0, 0)); d = ImageDraw.Draw(pl)
    d.rounded_rectangle((0, 0, pl.width - 1, pl.height - 1), radius=(h + 44) // 2, fill=(255, 255, 255, 225))
    cy = pl.height // 2; x0 = 30
    d.polygon([(x0, cy - 9), (x0 + 12, cy - 9), (x0 + 26, cy - 22), (x0 + 26, cy + 22), (x0 + 12, cy + 9), (x0, cy + 9)], fill=(31, 47, 90))
    for k, r in enumerate((14, 24)):
        d.arc((x0 + 26 - r, cy - r, x0 + 26 + r, cy + r), -45, 45, fill=(31, 47, 90), width=4)
    d.text((90 - b[0], cy - h // 2 - b[1]), t, font=f, fill=(31, 47, 90))
    out = Image.new("RGBA", (W, pl.height), (0, 0, 0, 0)); out.alpha_composite(pl, ((W - pl.width) // 2, 0))
    return out
