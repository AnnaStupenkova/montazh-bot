"""Мягкая ретушь кожи: маска кожи (YCrCb) + сглаживание с сохранением краёв.
Глаза, брови, губы, волосы почти не трогаются — они не попадают в маску кожи."""
import cv2, numpy as np


def skin_mask(bgr):
    ycc = cv2.cvtColor(bgr, cv2.COLOR_BGR2YCrCb)
    m = cv2.inRange(ycc, (40, 135, 85), (255, 175, 128))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    m = cv2.GaussianBlur(m, (0, 0), 6)
    return m.astype(np.float32) / 255.0


def smooth_skin(bgr, strength=0.45, keep_texture=0.6):
    h, w = bgr.shape[:2]
    sc = 720 / max(w, h) if max(w, h) > 720 else 1.0
    small = cv2.resize(bgr, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA) if sc < 1 else bgr
    sm = small
    sm = cv2.bilateralFilter(sm, 7, 28, 7)
    sm = cv2.resize(sm, (w, h), interpolation=cv2.INTER_CUBIC) if sc < 1 else sm
    img = bgr.astype(np.float32); s = sm.astype(np.float32)
    # частотное разделение: вернуть немного мелкой фактуры, чтобы кожа не была «пластиковой»
    hp = img - cv2.GaussianBlur(img, (0, 0), 1.2)
    res = s + hp * keep_texture
    m = skin_mask(bgr)[..., None] * strength
    out = img * (1 - m) + res * m
    # чуть теплее и светлее
    return np.clip(out, 0, 255).astype(np.uint8)


def retouch_file(path_in, path_out, strength=0.45):
    im = cv2.imread(path_in)
    cv2.imwrite(path_out, smooth_skin(im, strength), [cv2.IMWRITE_JPEG_QUALITY, 92])
