"""Распознавание речи: GigaAM v2 (Сбер, MIT) через sherpa-onnx + VAD. Пословные тайм-коды."""
import sherpa_onnx, soundfile as sf, numpy as np, os

MD = os.environ.get("MODELS", "/opt/montazh-models")
GA = MD + "/sherpa-onnx-nemo-transducer-giga-am-v2-russian-2025-04-19/"
_rec = None

def _recognizer(threads):
    global _rec
    if _rec is None:
        _rec = sherpa_onnx.OfflineRecognizer.from_transducer(
            encoder=GA + "encoder.int8.onnx", decoder=GA + "decoder.onnx", joiner=GA + "joiner.onnx",
            tokens=GA + "tokens.txt", num_threads=threads, model_type="nemo_transducer")
    return _rec

def transcribe(wav, threads=2):
    """wav: 16 кГц моно. Возвращает список слов [{w, s, e}] и фраз [{s, e, t}]."""
    a, sr = sf.read(wav, dtype="float32")
    cfg = sherpa_onnx.VadModelConfig()
    cfg.silero_vad.model = MD + "/silero_vad.onnx"
    cfg.silero_vad.min_silence_duration = 0.25
    cfg.silero_vad.max_speech_duration = 15
    cfg.sample_rate = 16000
    vad = sherpa_onnx.VoiceActivityDetector(cfg, buffer_size_in_seconds=600)
    segs = []
    for i in range(0, len(a), 512):
        vad.accept_waveform(a[i:i + 512])
        while not vad.empty():
            segs.append((vad.front.start, np.array(vad.front.samples))); vad.pop()
    vad.flush()
    while not vad.empty():
        segs.append((vad.front.start, np.array(vad.front.samples))); vad.pop()
    rec = _recognizer(threads)
    words, phrases = [], []
    for st, s in segs:
        x = rec.create_stream(); x.accept_waveform(16000, s); rec.decode_stream(x)
        r = x.result; b = st / 16000; e = b + len(s) / 16000
        toks, ts = list(r.tokens), list(r.timestamps)
        # собрать слова из BPE-токенов (▁ = начало слова)
        cur, cs = "", None; pw = []
        for tk, t in zip(toks, ts):
            if tk.strip() == "" or tk.startswith("▁"):
                if cur: pw.append([cur, cs]); cur = ""
                tk = tk.replace("▁", "").strip()
                if not tk: continue
            if not cur: cs = b + t
            cur += tk
        if cur: pw.append([cur, cs])
        for j, (w, s0) in enumerate(pw):
            s1 = pw[j + 1][1] - 0.02 if j + 1 < len(pw) else e
            words.append({"w": w, "s": round(s0, 3), "e": round(min(s1, s0 + 1.2), 3)})
        if pw: phrases.append({"s": round(b, 3), "e": round(e, 3), "t": " ".join(w for w, _ in pw)})
    return words, phrases

if __name__ == "__main__":
    import sys, json, time
    t = time.time(); w, p = transcribe(sys.argv[1])
    for x in p: print(f"{x['s']:.2f}-{x['e']:.2f} {x['t']}")
    print("words", len(w), "time %.1fs" % (time.time() - t))
    json.dump({"words": w, "phrases": p}, open(sys.argv[1] + ".ga.json", "w"), ensure_ascii=False)
