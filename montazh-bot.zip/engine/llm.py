"""ИИ-помощник: расстановка знаков, план вставок, хуки, описания.
Провайдеры: YandexGPT (YC_API_KEY + YC_FOLDER) или GigaChat (GIGACHAT_KEY). Без ключа — None."""
import os, json, re, ssl, time, uuid, base64, urllib.request, urllib.parse

YC_KEY = os.environ.get("YC_API_KEY"); YC_FOLDER = os.environ.get("YC_FOLDER")
GC_KEY = os.environ.get("GIGACHAT_KEY")
_gc_token = {"t": None, "exp": 0}


def available():
    return bool((YC_KEY and YC_FOLDER) or GC_KEY)


def _post(url, data, headers, ctx=None, form=False):
    body = (urllib.parse.urlencode(data) if form else json.dumps(data)).encode()
    req = urllib.request.Request(url, data=body, headers=headers)
    with urllib.request.urlopen(req, timeout=120, context=ctx) as r:
        return json.loads(r.read())


def _gc_ctx():
    # сертификат Минцифры: если установлен в систему — проверяется; иначе путь из GIGACHAT_CA
    ca = os.environ.get("GIGACHAT_CA")
    return ssl.create_default_context(cafile=ca) if ca else ssl.create_default_context()


def ask(system, user, temp=0.3, max_tokens=2000):
    if YC_KEY and YC_FOLDER:
        r = _post("https://llm.api.cloud.yandex.net/foundationModels/v1/completion",
                  {"modelUri": f"gpt://{YC_FOLDER}/yandexgpt/latest",
                   "completionOptions": {"stream": False, "temperature": temp, "maxTokens": str(max_tokens)},
                   "messages": [{"role": "system", "text": system}, {"role": "user", "text": user}]},
                  {"Authorization": f"Api-Key {YC_KEY}", "Content-Type": "application/json"})
        return r["result"]["alternatives"][0]["message"]["text"]
    if GC_KEY:
        import urllib.parse
        ctx = _gc_ctx()
        if not _gc_token["t"] or time.time() > _gc_token["exp"] - 60:
            r = _post("https://ngw.devices.sberbank.ru:9443/api/v2/oauth", {"scope": os.environ.get("GIGACHAT_SCOPE", "GIGACHAT_API_PERS")},
                      {"Authorization": f"Basic {GC_KEY}", "RqUID": str(uuid.uuid4()),
                       "Content-Type": "application/x-www-form-urlencoded"}, ctx, form=True)
            _gc_token["t"] = r["access_token"]; _gc_token["exp"] = r["expires_at"] / 1000
        r = _post("https://gigachat.devices.sberbank.ru/api/v1/chat/completions",
                  {"model": os.environ.get("GIGACHAT_MODEL", "GigaChat"), "temperature": temp, "max_tokens": max_tokens,
                   "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]},
                  {"Authorization": f"Bearer {_gc_token['t']}", "Content-Type": "application/json"}, ctx)
        return r["choices"][0]["message"]["content"]
    return None


def _json(s):
    m = re.search(r"\{.*\}", s or "", re.S)
    return json.loads(m.group(0)) if m else None


PUNCT_SYS = ("Ты редактор субтитров. Тебе дают распознанную речь без знаков препинания. "
             "Расставь знаки препинания, заглавные буквы, букву ё. Исправь только явные ошибки распознавания "
             "(не то слово, неверное окончание). НЕ сокращай, НЕ перефразируй, НЕ убирай слова-паразиты, "
             "сохрани порядок слов и переносы строк. Верни только текст.")


def punctuate(text):
    return ask(PUNCT_SYS, text, temp=0.1)


PLAN_SYS = """Ты помогаешь монтировать вертикальный рилс психолога. Голос тёплый, тема — состояние, забота о себе.
Тебе дают фразы с тайм-кодами (секунды). Верни JSON:
{"inserts":[{"at":секунда_начала_фразы,"phrase":"фраза","query":"английский запрос для видеостока, 2-4 слова"}],
 "hooks":["вариант хука 1","2","3"],
 "instagram":"описание для Instagram/ВК: 4-6 коротких абзацев на «ты», вопрос в конце, затем 6-8 хэштегов",
 "telegram":"текст для Telegram-канала на «вы», теплее и подробнее, без хэштегов, вопрос в конце",
 "youtube_title":"название до 70 символов","youtube_desc":"2 строки + 3 хэштега",
 "tiktok":"одна строка + 4-5 хэштегов"}
Правила вставок: 3-5 штук; только где фраза называет конкретный образ (утро, кровать, рассвет, чай, дневник, ключи, хлеб);
не раньше 8-й секунды; без людей и лиц в запросе (no people); светлые, мягкие кадры; не ставь вставку на каждую фразу.
Тексты пиши словами автора из рилса, не выдумывай фактов. Без слов «сложно/сложности» — только «трудно/трудности»."""


def plan(phrases):
    txt = "\n".join(f"[{p['s']:.1f}] {p['t']}" for p in phrases)
    return _json(ask(PLAN_SYS, txt, temp=0.4, max_tokens=3000))


def rewrite(kind, current, wish, full_text):
    sys = ("Перепиши текст для соцсети по пожеланию автора. Сохрани её слова и смысл рилса. Верни только текст.")
    return ask(sys, f"Тип: {kind}\nТекст рилса:\n{full_text}\n\nТекущий вариант:\n{current}\n\nПожелание: {wish}", temp=0.5)
